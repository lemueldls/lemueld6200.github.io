---
title: Jekyll on Ubuntu
permalink: /docs/installation/other-linux/
---
Installation on other Linux distributions works similarly as on Ubuntu.
 On Fedora, the dependencies can be installed as follows, and the rest
works the same as on Ubuntu.

 ```sh
sudo dnf install ruby ruby-devel @development-tools
```
